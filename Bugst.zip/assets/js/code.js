const keyBoard = document.querySelector('.txtb');


keyBoard.addEventListener('keydown', e => {
  if(e.keyCode === 13){
   e.preventDefault(); 
    if(e.target.value == 'Yummy')
      location.replace('1720386fydg1923f76g102306gf01236fg.html')
  }
  
  }
)

  
  
